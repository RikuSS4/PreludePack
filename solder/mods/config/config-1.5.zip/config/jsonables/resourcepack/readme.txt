This is the default!

NO TOUCHY!